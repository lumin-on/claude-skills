# 에이전트 업데이트 — kakao-agenda-review (Skill + Subagent 2개)

기존에 등록한 카카오톡 안건 판단·검증 에이전트를 오픈소스 3개로 업데이트한 결과물입니다.

## 무엇을 왜 바꿨나

실제 대화 11,341줄로 돌려 보고 나온 실패가 근거입니다(숫자만: [runs/test-03/00-baseline.md](runs/test-03/00-baseline.md)).

| 오픈소스 | 프로세스 블록 | 이 도구를 붙인 이유 |
|---|---|---|
| [openai/tiktoken](https://github.com/openai/tiktoken) | 원문 줄 번호·청크 분할 | 글자 수 눈대중 분할 → 토큰 예산. 파일 끝 개행이 없어 마지막 한 줄이 어느 청크에도 안 들어가던 버그 해소 |
| [rapidfuzz/RapidFuzz](https://github.com/rapidfuzz/RapidFuzz) | 인용 검증 | 인용 1,214건 중 16건이 줄 번호만 어긋났을 때 올바른 줄을 사람이 ±50줄 훑어 찾던 작업을 자동화 |
| [ajv-validator/ajv](https://github.com/ajv-validator/ajv) | 구조 검증 | 검증 규칙을 코드 하드코딩에서 `schemas/*.json` 선언으로 분리. 위반 위치를 JSON Pointer로 표시 |

## 업데이트한 파일

| 대상 | 파일 | 바뀐 내용 |
|---|---|---|
| Skill | [.claude/skills/kakao-agenda-review/SKILL.md](.claude/skills/kakao-agenda-review/SKILL.md) | 외부 도구 표 추가. 2단계를 `chunk_by_tokens.py` 호출로 교체(+`coverage.complete` 확인 전 진행 금지). 6단계를 ajv·RapidFuzz 2단 관문으로 교체. 청크가 여러 개일 때 메인이 청크 간 연결을 책임진다는 5단계 문장 추가. 공개 범위(실명·연락처·토큰 제외) 절 추가 |
| Subagent A | [.claude/agents/kakao-agenda-analyst.md](.claude/agents/kakao-agenda-analyst.md) | "offset·limit으로 나눠 읽지 말 것" 읽기 규칙 추가(드리프트 원인 차단). 줄 ID는 파일 접두어를 그대로 복사. 허용 상태값 밖 신규 값 금지(ajv 검사 명시) |
| Subagent B | [.claude/agents/kakao-evidence-reviewer.md](.claude/agents/kakao-evidence-reviewer.md) | 같은 읽기 규칙 추가. `citation-check.json`(RapidFuzz 결과)을 먼저 확인하고 `auto_fix`를 수정 제안에 쓰도록. revise·hold 시 `proposed_change` 필수(ajv 검사 명시) |
| 신규 스크립트 | [scripts/chunk_by_tokens.py](scripts/chunk_by_tokens.py) · [scripts/check_citations.py](scripts/check_citations.py) · [scripts/validate_schema.mjs](scripts/validate_schema.mjs) | 각 도구 호출부 |
| 신규 스키마 | [schemas/analyst-output.schema.json](schemas/analyst-output.schema.json) · [schemas/reviewer-output.schema.json](schemas/reviewer-output.schema.json) | 기존 하드코딩 규칙을 JSON Schema로 |

변경 전후 diff: [runs/test-03/00-diff.txt](runs/test-03/00-diff.txt) (원본은 `runs/test-03/before/`)

## 실행 결과

합성 대화 132줄로 파이프라인 전체를 돌렸습니다: [runs/test-03/](runs/test-03/)

- tiktoken 청킹 4청크, 커버리지 완전
- 분석 Subagent 4회 → 안건 29개 (전원 **tool_uses 1회**, 나눠 읽기 없음)
- ajv·RapidFuzz 관문 통과 → 검토 Subagent 4회 → accept 22 / revise 7 / hold 0
- 메인 조율 34건 (청크 간 연결 갱신 13건 포함)
- 최종 검증: 스키마 위반 0, 인용 118건 불일치 0

| 항목 | 업데이트 전 | 업데이트 후 |
|---|---|---|
| 인용 줄 번호 드리프트 | 1,214건 중 16건 (1.3%) | 101건 중 **0건** |
| 청크 커버리지 | 마지막 1줄 누락 | 완전 |
| 스키마 위반 발견 | 사람이 수동 발견 | ajv 자동, JSON Pointer 위치 표시 |
| 검증 시점 | 보고서 작성 후 1회 | A 직후·B 직후·최종 **3회** |

보고서: [runs/test-03/06-final-report.md](runs/test-03/06-final-report.md) · 조율 기록: [runs/test-03/03-coordination.md](runs/test-03/03-coordination.md)

## 검토 Subagent가 잡아낸 것

합성 대화에 제가 실수로 넣은 **날짜·요일 불일치**(10/24가 토요일이면 10/17도 토요일인데 "10월 17일 금요일"로 표기)를 검토 Subagent가 발견했습니다. 실제 단톡방에도 흔한 오류라 고치지 않고 사람 확인 사항으로 남겼습니다. 그 밖에 "반영하겠습니다"를 완료로 분류한 건, 무기한 보류를 해결로 분류한 건도 잡아냈습니다.

## 직접 돌려보기

```
pip install tiktoken rapidfuzz
npm install ajv

python scripts/chunk_by_tokens.py examples/synthetic-chat-long.txt --out work --budget 2000
node scripts/validate_schema.mjs --schema schemas/analyst-output.schema.json --json <분석결과.json>
python scripts/check_citations.py --indexed work/indexed.txt --json <결과.json>
```

Claude 앱 Code 탭 → Local → Select folder 로 이 폴더를 열면 Skill·Subagent가 인식됩니다.

## 포함하지 않은 것

실제 카카오톡 원문과 그 실행 결과는 넣지 않았습니다. 실명·연락처·인증번호가 들어 있어 로컬에만 두고, 근거가 되는 숫자만 `runs/test-03/00-baseline.md`에 옮겼습니다.

저장소: https://github.com/lumin-on/claude-skills
